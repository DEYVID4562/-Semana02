
def calcular_compra(precio_docena, cantidad_docenas):
    importe_compra = precio_docena * cantidad_docenas
    descuento = 0.20 if cantidad_docenas >= 10 else 0.10
    importe_descuento = importe_compra * descuento
    importe_pagar = importe_compra - importe_descuento
    lapiceros = 2 * cantidad_docenas if importe_pagar >= 200 else 0

    return {
        "Importe de la compra": round(importe_compra, 2),
        "Importe del descuento": round(importe_descuento, 2),
        "Importe a pagar": round(importe_pagar, 2),
        "Lapiceros de obsequio": lapiceros
    }

# Ejemplo
resultado_compra = calcular_compra(precio_docena=25.0, cantidad_docenas=12)
print(resultado_compra)
