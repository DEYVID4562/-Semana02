class Empleado:
    def __init__(self, categoria, horas_trabajadas, numero_hijos):
        self.categoria = categoria.upper()
        self.horas_trabajadas = horas_trabajadas
        self.numero_hijos = numero_hijos

    def calcular_sueldo_basico(self):
        tarifa = 45.0 if self.categoria == 'A' else 37.5
        return self.horas_trabajadas * tarifa

    def calcular_bonificacion(self):
        if self.numero_hijos <= 3:
            return self.numero_hijos * 40.5
        else:
            return self.numero_hijos * 35.0

    def calcular_sueldo_bruto(self):
        return self.calcular_sueldo_basico() + self.calcular_bonificacion()

    def calcular_descuento(self):
        sueldo_bruto = self.calcular_sueldo_bruto()
        tasa_descuento = 0.135 if sueldo_bruto >= 3500 else 0.10
        return sueldo_bruto * tasa_descuento

    def calcular_sueldo_neto(self):
        return self.calcular_sueldo_bruto() - self.calcular_descuento()


# Ejemplo de uso
empleado = Empleado(categoria='A', horas_trabajadas=80, numero_hijos=2)
print("Sueldo básico:", round(empleado.calcular_sueldo_basico(), 2))
print("Sueldo bruto:", round(empleado.calcular_sueldo_bruto(), 2))
print("Descuento:", round(empleado.calcular_descuento(), 2))
print("Sueldo neto:", round(empleado.calcular_sueldo_neto(), 2))
